export const config = {
  "dev": {
    "username": "udagramruttnerdev",
    "password": "udagramruttnerdev",
    "database": "udagramruttnerdev",
    "host": "udagramruttnerdev.c79fzt27bzf6.us-east-2.rds.amazonaws.com",
    "dialect": "postgres",
    "aws_reigion": "us-east-2",
    "aws_profile": "default",
    "aws_media_bucket": "udagram-ruttner-dev"
  },
  "prod": {
    "username": "",
    "password": "",
    "database": "udagram_prod",
    "host": "",
    "dialect": "postgres"
  }
}
